/**
 * @namespace Phaser.Types.Display
 */
