/**
 * @callback Phaser.Types.GameObjects.Group.GroupCallback
 * @since 3.0.0
 *
 * @param {Phaser.GameObjects.GameObject} item - A group member
 */
